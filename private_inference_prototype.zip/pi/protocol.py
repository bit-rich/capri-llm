"""
End-to-end single-server private inference for an open-weight GPT-style model.

Server sees only: Ring-LWE ciphertexts of activations (online) and BFV ciphertexts of
mask secrets (offline). It runs plain int8 GEMVs online. Client does masking, unmasking,
LayerNorm/GELU/softmax/attention, and holds the KV cache.
"""
import ctypes, time, numpy as np
from crypto import InnerLWE, BFV, BFV32, offline_hint_products, offline_hint_products_v2, dgauss, Q32

lib = ctypes.CDLL("./libk.so")
P = ctypes.c_void_p
for f in (lib.gemv_i8_i8, lib.gemv_i8_u32):
    f.argtypes = [P, P, P, ctypes.c_size_t, ctypes.c_size_t]

def gemv_u32(W, c):
    y = np.empty(W.shape[0], dtype=np.uint32); c = np.ascontiguousarray(c, dtype=np.uint32)
    lib.gemv_i8_u32(W.ctypes.data, c.ctypes.data, y.ctypes.data, W.shape[0], W.shape[1]); return y

def gemv_i8(W, x):
    y = np.empty(W.shape[0], dtype=np.int32); x = np.ascontiguousarray(x, dtype=np.int8)
    lib.gemv_i8_i8(W.ctypes.data, x.ctypes.data, y.ctypes.data, W.shape[0], W.shape[1]); return y


# ---------------------------------------------------------------- model
class Linear:
    def __init__(self, W):                       # W float (d_out, d_in) -> per-row int8
        self.scale = np.abs(W).max(1) / 127.0
        self.q = np.clip(np.rint(W / self.scale[:, None]), -127, 127).astype(np.int8)
        self.row_norm_max = np.sqrt((self.q.astype(np.float64) ** 2).sum(1)).max()
    def plain(self, x):                          # plaintext W8 reference (float activations)
        return (self.q.astype(np.float64) @ x) * self.scale

def layernorm(x): return (x - x.mean()) / np.sqrt(x.var() + 1e-5)
def gelu(x): return 0.5 * x * (1 + np.tanh(0.7978845608 * (x + 0.044715 * x ** 3)))

class Model:
    def __init__(self, vocab=4096, d=1024, layers=4, heads=16, ffn=4096, seed=0):
        rng = np.random.default_rng(seed)
        g = lambda *s: rng.normal(0, 0.02, s)
        self.d, self.h, self.L, self.vocab = d, heads, layers, vocab
        self.embed = Linear(rng.normal(0, 1.0, (d, vocab)))       # one-hot input -> d
        self.blocks = [dict(qkv=Linear(g(3 * d, d)), o=Linear(g(d, d) / np.sqrt(2 * layers)),
                            up=Linear(g(ffn, d)), down=Linear(g(d, ffn) / np.sqrt(2 * layers)))
                       for _ in range(layers)]
        self.head = Linear(g(vocab, d))
    def linears(self):
        out = [("embed", self.embed)]
        for i, b in enumerate(self.blocks):
            out += [(f"{i}.{k}", b[k]) for k in ("qkv", "o", "up", "down")]
        return out + [("head", self.head)]

def attend(q, K, V, heads):
    d = q.shape[0]; hd = d // heads
    qh = q.reshape(heads, hd); Kh = K.reshape(-1, heads, hd); Vh = V.reshape(-1, heads, hd)
    s = np.einsum("hd,thd->ht", qh, Kh) / np.sqrt(hd)
    s = np.exp(s - s.max(1, keepdims=True)); s /= s.sum(1, keepdims=True)
    return np.einsum("ht,thd->hd", s, Vh).reshape(d)

def forward_token(model, tok, cache, lin):
    """One decode step. `lin(name, layer, x)` performs the linear layer (plain or private)."""
    x = np.zeros(model.vocab); x[tok] = 1.0
    x = lin("embed", model.embed, x)
    for i, b in enumerate(model.blocks):
        qkv = lin(f"{i}.qkv", b["qkv"], layernorm(x))
        q, k, v = np.split(qkv, 3)
        cache[i][0].append(k); cache[i][1].append(v)
        a = attend(q, np.array(cache[i][0]), np.array(cache[i][1]), model.h)
        x = x + lin(f"{i}.o", b["o"], a)
        x = x + lin(f"{i}.down", b["down"], gelu(lin(f"{i}.up", b["up"], layernorm(x))))
    return lin("head", model.head, layernorm(x))


# ---------------------------------------------------------------- private protocol
class Server:
    """Holds public weights + public hints. Never sees plaintext activations or secrets."""
    def __init__(self, model, lwe):
        self.lin = dict(model.linears()); self.lwe = lwe
        self.a = {}; self.H = {}
        for lid, (name, L) in enumerate(model.linears()):
            self.a[name] = lwe.public_a(lid, L.q.shape[1])
            self.H[name] = lwe.hint(L.q, self.a[name])              # one-time, public
        self.order = [n for n, _ in model.linears()]
        self.H_all = np.concatenate([self.H[n] for n in self.order])  # (D_total, n)
        self.time_online = 0.0
    def online(self, name, c):
        t = time.perf_counter(); y = gemv_u32(self.lin[name].q, c); self.time_online += time.perf_counter() - t
        return y

class Client:
    def __init__(self, server, lwe, bfv, seed=7):
        self.srv, self.lwe, self.bfv = server, lwe, bfv
        self.rng = np.random.default_rng(seed)
        self.t_mask = self.t_unmask = 0.0
        self.up_bytes = self.down_bytes = 0
        self.rounds = 0

    def offline(self, n_tokens):
        """Draw a fresh secret alpha per future token; get z = H alpha for every layer via BFV."""
        self.alphas = dgauss(self.rng, (n_tokens, self.lwe.n), self.lwe.sigma)
        f = offline_hint_products_v2 if isinstance(self.bfv, BFV32) else offline_hint_products
        z, srv_s, cli_s, up, down = f(self.bfv, self.srv.H_all, self.alphas)
        self.z = {}; off = 0
        for name in self.srv.order:
            D = self.srv.H[name].shape[0]; self.z[name] = z[:, off:off + D]; off += D
        self.tok = 0
        return dict(server_s=srv_s, client_s=cli_s, up_bytes=up, down_bytes=down)

    def lin(self, name, L, x):
        t0 = time.perf_counter()
        nx = np.linalg.norm(x)
        S = 2.0 ** 30 / (L.row_norm_max * nx) if nx > 0 else 1.0     # Cauchy-Schwarz: no wraparound
        xt = np.rint(x * S).astype(np.int64)
        c = (self.lwe.mask(self.srv.a[name], self.alphas[self.tok], len(x), self.rng) + xt) & 0xFFFFFFFF
        t1 = time.perf_counter()
        y = self.srv.online(name, c.astype(np.uint32))                # ---- network round trip ----
        t2 = time.perf_counter()
        r = (y.astype(np.int64) - self.z[name][self.tok]) & 0xFFFFFFFF
        r = np.where(r >= 1 << 31, r - Q32, r)                         # = M x~ + M e  (centred)
        out = r / S * L.scale
        t3 = time.perf_counter()
        self.t_mask += t1 - t0; self.t_unmask += t3 - t2
        self.up_bytes += 4 * len(c); self.down_bytes += 4 * len(y); self.rounds += 1
        return out
