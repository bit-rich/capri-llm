import time, json, numpy as np
from protocol import *

T = 64  # tokens to decode
model = Model()
import sys
lwe, bfv = InnerLWE(), (BFV32() if 'v2' in sys.argv else BFV())

t = time.perf_counter(); server = Server(model, lwe); t_setup = time.perf_counter() - t
client = Client(server, lwe, bfv)
off = client.offline(T)
print("offline:", {k: round(v, 3) for k, v in off.items()}, "setup", round(t_setup, 1))

rng = np.random.default_rng(3)
toks = rng.integers(0, model.vocab, T)

# plaintext W8 reference
cache_p = [([], []) for _ in model.blocks]
plain_logits = [forward_token(model, tk, cache_p, lambda n, L, x: L.plain(x)) for tk in toks]

# private
cache_c = [([], []) for _ in model.blocks]
priv_logits, t_tok = [], []
for i, tk in enumerate(toks):
    client.tok = i
    t = time.perf_counter()
    priv_logits.append(forward_token(model, tk, cache_c, client.lin))
    t_tok.append(time.perf_counter() - t)
P_, C_ = np.array(plain_logits), np.array(priv_logits)
rel = np.linalg.norm(P_ - C_, axis=1) / np.linalg.norm(P_, axis=1)
top1 = (P_.argmax(1) == C_.argmax(1)).mean()

# plaintext server baseline: same GEMVs with int8 activations
names = server.order
t = time.perf_counter()
for _ in range(T):
    for n in names:
        L = server.lin[n]; gemv_i8(L.q, np.zeros(L.q.shape[1], np.int8))
t_plain_gemv = (time.perf_counter() - t) / T

res = dict(
    logits_rel_err_max=float(rel.max()), logits_rel_err_mean=float(rel.mean()), top1_agree=float(top1),
    server_online_s_per_tok=server.time_online / T, server_plain_int8_s_per_tok=t_plain_gemv,
    online_overhead=server.time_online / T / t_plain_gemv,
    client_mask_s_per_tok=client.t_mask / T, client_unmask_s_per_tok=client.t_unmask / T,
    private_total_s_per_tok_excl_network=float(np.mean(t_tok)),
    rounds_per_tok=client.rounds / T,
    online_up_KB_per_tok=client.up_bytes / T / 1e3, online_down_KB_per_tok=client.down_bytes / T / 1e3,
    offline_server_s_per_tok_amortized=off["server_s"] / bfv.N,
    offline_client_s_per_tok_amortized=off["client_s"] / bfv.N,
    offline_up_KB_per_tok=off["up_bytes"] / bfv.N / 1e3, offline_down_KB_per_tok=off["down_bytes"] / bfv.N / 1e3,
    D_total=int(server.H_all.shape[0]), params=int(sum(L.q.size for _, L in model.linears())),
)
print(json.dumps(res, indent=1))
json.dump(res, open("results_v2.json" if "v2" in sys.argv else "results.json", "w"), indent=1)
