# Single-server private inference for open-weight LLMs (prototype)

The server learns nothing about the prompt. No second server and no trusted hardware are involved.

## Idea
- **Linear layers (server):** the client sends Ring-LWE-masked activations `c = a*alpha + e + x` (mod 2^32, n=1024). The server runs an ordinary int8 GEMV `y = M c`, which is the same work as plaintext.
- **Unmasking (client):** the client computes `M x ~= y - H alpha`, where `H = M A` is public and precomputed by the server.
- **`H alpha` ahead of time:** this is computed in advance under BFV encryption (batched over 4096 future tokens, then compressed to one ~30-bit limb). The approach follows Tiptoe's "token" (Henzinger et al., SOSP 2023), applied here to every layer of an LLM.
- **Nonlinear parts (client):** the client does LayerNorm, GELU, softmax and attention, and holds the KV cache.

## Measured (random-weight GPT, d=1024, 4 layers, vocab 4096, 64 tokens; 2-core CPU)
- Top-1 token agreement with the plaintext W8 model is 100%. Logit relative error is 0.11%.
- Online server time per token is 0.99x the plaintext int8 GEMV time.
- Per-layer noise is about 1e-3 with guaranteed no-wraparound scaling, and about 1.2e-4 with 8-sigma scaling.
- Ahead-of-time cost per token: 315 KB download, 23 KB upload, 61 ms server (numpy), 11 ms client (numpy).

## Files
- `crypto.py`: NTT, ring-LWE masks, hint, BFV offline scheme (v1 BGV-batched, v2 compressed)
- `protocol.py`: model, client, server
- `kernels.c`: int8 GEMV kernels
- `run.py [v2]`: end-to-end run
- `costmodel.py`: per-token projections for 7B, 70B and DeepSeek-V3
- `test_*.py`: correctness tests

Build: `gcc -O3 -march=native -shared -fPIC kernels.c -o libk.so && python3 run.py v2`

## Caveats
- Lattice parameters follow SimplePIR and the HE standard, but have not been checked with the lattice estimator.
- The server is semi-honest. Privacy should hold against a malicious server, but integrity is not provided.
- The weights are random, not a trained model.
- Ahead-of-time costs are measured in numpy. GPU figures are estimates from operation counts.
